<!DOCTYPE html>
<html>

<head>
    <title>Star Admin Pro Laravel Dashboard Template</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset('/favicon.ico')); ?>">

    <!-- plugin css -->
    <?php echo Html::style('assets/plugins/@mdi/font/css/materialdesignicons.min.css'); ?>

    <?php echo Html::style('assets/plugins/perfect-scrollbar/perfect-scrollbar.css'); ?>

    <!-- end plugin css -->

    <link href="<?php echo e(asset('assets/fa6.4/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/DataTables/datatables.min.css')); ?>" rel="stylesheet" />

    <?php echo $__env->yieldPushContent('plugin-styles'); ?>

    <!-- common css -->
    <?php echo Html::style('css/app.css'); ?>

    <!-- end common css -->

    <style>
        .nav-container {
            position: relative;
        }

        .breadcrumb-button {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
        }
    </style>

    <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body data-base-url="<?php echo e(url('/')); ?>">

    <div class="container-scroller" id="app">
        <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid page-body-wrapper">
            <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-panel">
                <div class="content-wrapper">
                    <script>
                        var message = "<?php echo isset($message) ? $message : 0 ?>";
                        if(message != '0'){
                            alert(message);
                        }
                    </script>

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>

    <!-- base js -->
    <?php echo Html::script('js/app.js'); ?>

    <?php echo Html::script('assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js'); ?>

    <!-- end base js -->

    <!-- plugin js -->
    <?php echo $__env->yieldPushContent('plugin-scripts'); ?>
    <!-- end plugin js -->

    <script src="<?php echo e(asset('assets/fa6.4/js/all.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/DataTables/datatables.min.js')); ?>"></script>
    <script>
        $(function() {
            $(".datatable").DataTable();
        });
    </script>
    <!-- common js -->
    <?php echo Html::script('assets/js/off-canvas.js'); ?>

    <?php echo Html::script('assets/js/hoverable-collapse.js'); ?>

    <?php echo Html::script('assets/js/misc.js'); ?>

    <?php echo Html::script('assets/js/settings.js'); ?>

    <?php echo Html::script('assets/js/todolist.js'); ?>

    <!-- end common js -->

    <?php echo $__env->yieldPushContent('custom-scripts'); ?>
</body>

</html>
<?php /**PATH D:\laragon\www\mslifepartner\resources\views/layout/master.blade.php ENDPATH**/ ?>