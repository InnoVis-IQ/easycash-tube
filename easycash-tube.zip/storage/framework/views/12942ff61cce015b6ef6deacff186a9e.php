

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Support Request #<?php echo e($supportRequest->id); ?></h3>
                    <div class="card-tools">
                        <a href="<?php echo e(route('admin.support.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to List
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-8">
                            <!-- Support Request Details -->
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title">Request Details</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row mb-3">
                                        <div class="col-md-3"><strong>User:</strong></div>
                                        <div class="col-md-9"><?php echo e($supportRequest->user->name ?? 'N/A'); ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-3"><strong>Email:</strong></div>
                                        <div class="col-md-9"><?php echo e($supportRequest->user->email ?? 'N/A'); ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-3"><strong>Subject:</strong></div>
                                        <div class="col-md-9"><?php echo e($supportRequest->subject); ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-3"><strong>Category:</strong></div>
                                        <div class="col-md-9">
                                            <span class="badge badge-info"><?php echo e(ucfirst($supportRequest->category)); ?></span>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-3"><strong>Status:</strong></div>
                                        <div class="col-md-9">
                                            <?php switch($supportRequest->status):
                                                case ('open'): ?>
                                                    <span class="badge badge-warning">Open</span>
                                                    <?php break; ?>
                                                <?php case ('in_progress'): ?>
                                                    <span class="badge badge-primary">In Progress</span>
                                                    <?php break; ?>
                                                <?php case ('resolved'): ?>
                                                    <span class="badge badge-success">Resolved</span>
                                                    <?php break; ?>
                                                <?php case ('closed'): ?>
                                                    <span class="badge badge-secondary">Closed</span>
                                                    <?php break; ?>
                                                <?php default: ?>
                                                    <span class="badge badge-light"><?php echo e(ucfirst($supportRequest->status)); ?></span>
                                            <?php endswitch; ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-3"><strong>Created:</strong></div>
                                        <div class="col-md-9"><?php echo e($supportRequest->created_at->format('M d, Y H:i')); ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-3"><strong>Message:</strong></div>
                                        <div class="col-md-9">
                                            <div class="border p-3 bg-light">
                                                <?php echo e($supportRequest->message); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Admin Response Section -->
                            <?php if($supportRequest->admin_response): ?>
                                <div class="card mt-4">
                                    <div class="card-header">
                                        <h5 class="card-title">Admin Response</h5>
                                        <small class="text-muted">Responded on <?php echo e($supportRequest->admin_response_at->format('M d, Y H:i')); ?></small>
                                    </div>
                                    <div class="card-body">
                                        <div class="border p-3 bg-light">
                                            <?php echo e($supportRequest->admin_response); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Response Form -->
                            <?php if($supportRequest->status !== 'closed'): ?>
                                <div class="card mt-4">
                                    <div class="card-header">
                                        <h5 class="card-title">Respond to Request</h5>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.support.respond', $supportRequest->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="admin_response">Response</label>
                                                <textarea name="admin_response" id="admin_response" rows="5" 
                                                          class="form-control <?php $__errorArgs = ['admin_response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                          placeholder="Enter your response..." required><?php echo e(old('admin_response')); ?></textarea>
                                                <?php $__errorArgs = ['admin_response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-paper-plane"></i> Send Response
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-4">
                            <!-- Status Update -->
                            <?php if($supportRequest->status !== 'closed'): ?>
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="card-title">Update Status</h5>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.support.update-status', $supportRequest->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="status">Status</label>
                                                <select name="status" id="status" class="form-control">
                                                    <option value="open" <?php echo e($supportRequest->status === 'open' ? 'selected' : ''); ?>>Open</option>
                                                    <option value="in_progress" <?php echo e($supportRequest->status === 'in_progress' ? 'selected' : ''); ?>>In Progress</option>
                                                    <option value="resolved" <?php echo e($supportRequest->status === 'resolved' ? 'selected' : ''); ?>>Resolved</option>
                                                    <option value="closed" <?php echo e($supportRequest->status === 'closed' ? 'selected' : ''); ?>>Closed</option>
                                                </select>
                                            </div>
                                            <button type="submit" class="btn btn-warning">
                                                <i class="fas fa-save"></i> Update Status
                                            </button>
                                        </form>
                                    </div>
                                </div>

                                <!-- Quick Actions -->
                                <div class="card mt-3">
                                    <div class="card-header">
                                        <h5 class="card-title">Quick Actions</h5>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.support.close', $supportRequest->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-secondary btn-block" 
                                                    onclick="return confirm('Are you sure you want to close this request?')">
                                                <i class="fas fa-times"></i> Close Request
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/admin/support/show.blade.php ENDPATH**/ ?>