<?php $__env->startPush('plugin-styles'); ?>
    
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/rowreorder/1.3.3/css/rowReorder.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-2">
    <?php if(isset($message) && $message != '0'): ?>
        <div class="alert alert-info">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>

    <!-- Eligibility Status -->
    <?php if(isset($eligibilityMessage) && $eligibilityMessage): ?>
        <div class="alert alert-warning">
            <i class="fa-solid fa-exclamation-triangle me-2"></i>
            <strong>Withdrawal Eligibility:</strong> <?php echo e($eligibilityMessage); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-3 offset-md-1 stretch-card mb-3">
            <div class="card card-statistics">
                <div class="card-body">
                    <div
                        class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
                        <div class="float-left">
                            <i class="fa-solid fa-coins fa-2xl"></i>
                        </div>
                        <div class="float-right">
                            <p class="mb-0 text-right">Account Balance</p>
                            <div class="fluid-container">
                                <h3 class="font-weight-medium text-right mb-0"><?php echo e($netAmount + $userWithdraws); ?> PKR</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 stretch-card mb-3">
            <div class="card card-statistics">
                <div class="card-body">
                    <div
                        class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
                        <div class="float-left">
                            <i class="fa-solid fa-coins fa-2xl"></i>
                        </div>
                        <div class="float-right">
                            <p class="mb-0 text-right">Withdrawals Requested</p>
                            <div class="fluid-container">
                                <h3 class="font-weight-medium text-right mb-0"><?php echo e($userWithdraws); ?> PKR</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 stretch-card mb-3">
            <div class="card card-statistics">
                <div class="card-body">
                    <div
                        class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
                        <div class="float-left">
                            <i class="fa-solid fa-coins fa-2xl"></i>
                        </div>
                        <div class="float-right">
                            <p class="mb-0 text-right">Available for Withdrawal</p>
                            <div class="fluid-container">
                                <h3 class="font-weight-medium text-right mb-0"><?php echo e($netAmount); ?> PKR</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Previous Plans Status -->
    <?php if(isset($previousPlans) && $previousPlans->count() > 0): ?>
        <div class="card mb-3">
            <div class="card-header bg-success text-white">
                <h5><i class="fas fa-check-circle"></i> Completed Plans</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $previousPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-2">
                            <div class="border rounded p-3">
                                <strong><?php echo e($plan->plan->title ?? 'Plan'); ?></strong><br>
                                <small class="text-muted">Completed on <?php echo e($plan->expire_at->format('M d, Y')); ?></small>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Withdrawal Rules Reminder -->
    <div class="card mb-3">
        <div class="card-header bg-info text-white">
            <h5><i class="fas fa-info-circle"></i> Withdrawal Rules</h5>
        </div>
        <div class="card-body">
            <ul class="list-unstyled mb-0">
                <li><i class="fas fa-check text-success"></i> Withdrawals only available after completing a plan</li>
                <li><i class="fas fa-check text-success"></i> Withdrawals can only be made for the completed plans</li>
                <li><i class="fas fa-check text-success"></i> Withdrawal requests are processed within 24-48 hours</li>
                <li><i class="fas fa-check text-success"></i> Supported payment methods: Easypaisa, JazzCash, NayaPay</li>
            </ul>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-header">
            <h4 style="font-weight: bold;">Request Withdrawal</h4>
        </div>
        <div class="card-body">
            <?php if($isEligible): ?>
            <form action="<?php echo e(route('withdraws.store')); ?>" method="POST" class="form row">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="userID" value="<?php echo e(Auth::user()['id']); ?>">
                <div class="col-md-8 offset-md-2">
                    <div class="form-group row">
                        <div class="col-md-5">
                            <label>Payment Method</label>
                        </div>
                        <div class="col-md-7">
                            <select name="payment_method" class="form-control" required>
                                <option value="">Select Payment Method</option>
                                <option value="easypaisa">Easypaisa</option>
                                <option value="jazzcash">JazzCash</option>
                                <option value="nayapay">NayaPay</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-5">
                            <label>Account Number</label>
                        </div>
                        <div class="col-md-7">
                            <input type="text" name="acc_number" placeholder="03001234567" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-5">
                            <label>Account Title</label>
                        </div>
                        <div class="col-md-7">
                            <input type="text" name="acc_title" placeholder="MUHAMMAD AHMED" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-5">
                            <label>Amount (PKR)</label>
                        </div>
                        <div class="col-md-7">
                            <input type="number" name="amount" min="500" max="<?php echo e($netAmount); ?>" placeholder="500"
                                class="form-control" required>
                            <small class="text-muted">Minimum: Rs. 500, Maximum: Rs. <?php echo e($netAmount); ?></small>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="text-center">
                            <input type="submit" name="submit" value="Request Withdrawal" class="btn btn-warning">
                        </div>
                    </div>
                </div>
            </form>
            <?php else: ?>
            <div class="alert alert-danger">
                <h4><i class="fa-solid fa-lock me-2"></i>Withdrawals Not Available</h4>
                <p>Withdrawals are only available after completing a plan. You need to finish your current plan before you can withdraw earnings.</p>
                <p>
                    <a href="<?php echo e(route('plans.index')); ?>" class="btn btn-primary">
                        <i class="fa-solid fa-compass-drafting me-2"></i>View Plans
                    </a>
                    <a href="<?php echo e(route('videos.watch')); ?>" class="btn btn-success">
                        <i class="fa-solid fa-play me-2"></i>Watch Videos
                    </a>
                </p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 style="font-weight: bold;">Withdrawal History</h4>
        </div>
        <div class="card-body">
            <?php if($withdrawalHistory->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Payment Method</th>
                                <th>Account Number</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $withdrawalHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($withdrawal->created_at->format('M d, Y H:i')); ?></td>
                                    <td><?php echo e($withdrawal->amount); ?> PKR</td>
                                    <td>
                                        <?php if($withdrawal->user_bank): ?>
                                            <?php echo e(ucfirst($withdrawal->user_bank->account_title ?? 'N/A')); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($withdrawal->user_bank): ?>
                                            <?php echo e($withdrawal->user_bank->account_number ?? 'N/A'); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($withdrawal->status == 'transferred' ? 'success' : ($withdrawal->status == 'requested' ? 'warning' : 'secondary')); ?>">
                                            <?php echo e(ucfirst($withdrawal->status)); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center">No withdrawal history found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>



<style>
/* Mobile specific styles */
@media (max-width: 768px) {
    .container-fluid {
        padding-left: 10px;
        padding-right: 10px;
    }
    
    .card-body {
        padding: 0.75rem;
    }
    
    .btn-sm {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
    }
    
    .table-responsive {
        font-size: 0.875rem;
    }
    

    
    .card-header {
        padding: 0.75rem;
    }
    
    .form-control-sm {
        font-size: 0.875rem;
    }
}

@media (max-width: 576px) {
    .col-12 {
        margin-bottom: 0.5rem;
    }
    
    .table-responsive {
        font-size: 0.75rem;
    }
    
    .btn-sm {
        font-size: 0.75rem;
        padding: 0.2rem 0.4rem;
    }
    
    .form-control-sm {
        font-size: 0.75rem;
    }
}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <?php echo Html::script('/assets/plugins/chartjs/chart.min.js'); ?>

    <?php echo Html::script('/assets/plugins/jquery-sparkline/jquery.sparkline.min.js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script type="text/javascript" src="https://cdn.datatables.net/rowreorder/1.3.3/js/dataTables.rowReorder.min.js">
    </script>
    <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js">
    </script>
    <?php echo Html::script('/assets/js/dashboard.js'); ?>


    <script>
        $(document).ready(function() {
            var table = $('#responsive-datatables').DataTable({
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/user/withdraw/index.blade.php ENDPATH**/ ?>