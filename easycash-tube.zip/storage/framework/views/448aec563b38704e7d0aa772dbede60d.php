<nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
        <a class="navbar-brand brand-logo text-primary" href="<?php echo e(url('/')); ?>">
            <!--<img src="<?php echo e(url('assets/images/logo.svg')); ?>" alt="logo" />-->
          <b>  MS Life Partner</b>
        </a>
        <a class="navbar-brand brand-logo-mini text-primary" href="<?php echo e(url('/')); ?>">
            <!--<img src="<?php echo e(url('assets/images/logo-mini.svg')); ?>" alt="logo" /> -->
          <b>  MLP</b>
        </a>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
        </button>
        
        <ul class="navbar-nav navbar-nav-right">
            
            
            <li class="nav-item dropdown d-none d-xl-inline-block">
                <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown"
                    aria-expanded="false">
                    <span class="profile-text d-none d-md-inline-flex"><?php echo e(Auth::user()['name']); ?></span>
                    <img class="img-xs rounded-circle" src="<?php echo e(url('assets/images/faces/face0.png')); ?>"
                        alt="Profile image"> </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                    
                    
                    
                    
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="submit" name="logout" value="Logout" class="btn btn-link dropdown-item">
                    </form>
                </div>
            </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
            data-toggle="offcanvas">
            <span class="mdi mdi-menu icon-menu"></span>
        </button>
    </div>
</nav>
<?php /**PATH D:\laragon\www\mslifepartner\resources\views/layout/header.blade.php ENDPATH**/ ?>