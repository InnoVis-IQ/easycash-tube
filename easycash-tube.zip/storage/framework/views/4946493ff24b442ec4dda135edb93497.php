<?php $__env->startPush('plugin-styles'); ?>
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/rowreorder/1.3.3/css/rowReorder.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $route = explode('.', Route::currentRouteName());
    ?>

    <?php
        $invested = 0;
        $earned = 0;
        $refEarnings = 0;
    ?>

    <div class="nav-container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route($route[0] . '.index')); ?>"><?php echo e(ucfirst($route[0])); ?></a></li>
            <li class="breadcrumb-item active"><a
                    href="<?php echo e(route($route[0] . '.show', $data['id'])); ?>"><?php echo e($data['name']); ?></a>
            </li>
            
        </ol>
    </div>
    <div class="card mb-3">
        <div class="card-header">
            <h4 style="font-weight: bold;"><?php echo e($data['name']); ?></h4>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-header row m-0">
            <div class="col-md-8" style="float: left;">
                <h4 style="font-weight: bold;">Investment Plans</h4>
            </div>
            <div class="col-md-4" style="float: right">
                <div class="row">
                    <div class="col-8 text-left">Life-time Investment:</div>
                    <div class="col-4 text-right"><span id="invested"></span> PKR</div>
                </div>
                <div class="row">
                    <div class="col-8 text-left">Life-time Earning:</div>
                    <div class="col-4 text-right"><span id="earned"></span> PKR</div>
                </div>
            </div>
        </div>
        <div class="card-body row">
            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $remainingDays = (strtotime(date('Y-m-d', strtotime($subscription['expire_at']))) - strtotime(date('Y-m-d'))) / (60 * 60 * 24);
                    $invested += $subscription['plan']['amount'];
                    $earned += $subscription['plan']['daily_profit'] * ($subscription['plan']['plan_days'] - $remainingDays);
                ?>
                <div class="col-md-4 col-sm-6 mb-3">
                    <div class="card border border-info">
                        <div class="card-header bg-primary text-white text-center p-0">
                            <?php echo e($subscription['plan']['title']); ?>

                        </div>
                        <div class="card-body p-0 px-1">
                            <div class="row">
                                <div class="col-7 text-left">Plan cost:</div>
                                <div class="col-5 text-right"><?php echo e($subscription['plan']['amount']); ?> PKR</div>
                            </div>
                            <div class="row">
                                <div class="col-7 text-left">Daily Profit:</div>
                                <div class="col-5 text-right"><?php echo e($subscription['plan']['daily_profit']); ?> PKR</div>
                            </div>
                            <div class="row">
                                <div class="col-7 text-left">Profit Earned:</div>
                                <div class="col-5 text-right">
                                    <?php echo e($subscription['earning']); ?>

                                    PKR</div>
                            </div>
                            <div class="row">
                                <div class="col-7 text-left">Plan Ending in:</div>
                                <div class="col-5 text-right"><?php echo e($remainingDays); ?> days</div>
                            </div>
                            <div class="row">
                                <div class="col-7 text-left">Total Profit:</div>
                                <div class="col-5 text-right"><?php echo e($subscription['plan']['total_profit']); ?> PKR</div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="card">
        <div class="card-header row m-0">
            <div class="col-md-8" style="float: left;">
                <h4 style="font-weight: bold;">Referrals</h4>
            </div>
            <div class="col-md-4" style="float: right">
                <div class="row">
                    <div class="col-8 text-left">Referrals Earning:</div>
                    <div class="col-4 text-right"><span id="invested"></span> PKR</div>
                </div>
            </div>
        </div>
        <div class="card-body row">
            [coming soon]
            <table class="table table-responsive" hidden>
                <thead>
                    <tr>
                        <th>Ser</th>
                        <th>Name</th>
                        <th>Earning</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script type="text/javascript" src="https://cdn.datatables.net/rowreorder/1.3.3/js/dataTables.rowReorder.min.js">
    </script>
    <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js">
    </script>
    <?php echo Html::script('/assets/js/dashboard.js'); ?>


    <script>
        $(document).ready(function() {
            var table = $('#responsive-datatables').DataTable({
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true
            });

            $("#invested").html(<?php echo e($invested); ?>);
            $("#earned").html(<?php echo e($earned); ?>);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/admin/users/show.blade.php ENDPATH**/ ?>