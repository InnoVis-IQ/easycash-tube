<?php $__env->startPush('plugin-styles'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Support Request Details</h2>
        <a href="<?php echo e(route('support.history')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to History
        </a>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo e($supportRequest->subject); ?></h5>
                <span class="badge bg-<?php echo e($supportRequest->status == 'open' ? 'warning' : ($supportRequest->status == 'closed' ? 'success' : 'info')); ?>">
                    <?php echo e(ucfirst($supportRequest->status)); ?>

                </span>
            </div>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-3">
                    <strong>Category:</strong>
                    <span class="badge bg-info"><?php echo e(ucfirst($supportRequest->category)); ?></span>
                </div>
                <div class="col-md-3">
                    <strong>Priority:</strong>
                    <span class="badge bg-<?php echo e($supportRequest->priority == 'high' ? 'danger' : ($supportRequest->priority == 'medium' ? 'warning' : 'success')); ?>">
                        <?php echo e(ucfirst($supportRequest->priority)); ?>

                    </span>
                </div>
                <div class="col-md-3">
                    <strong>Submitted:</strong>
                    <?php echo e($supportRequest->created_at->format('M d, Y H:i')); ?>

                </div>
                <div class="col-md-3">
                    <strong>Ticket ID:</strong>
                    #<?php echo e($supportRequest->id); ?>

                </div>
            </div>

            <div class="mb-4">
                <h6><strong>Your Message:</strong></h6>
                <div class="border rounded p-3 bg-light">
                    <?php echo nl2br(e($supportRequest->message)); ?>

                </div>
            </div>

            <?php if($supportRequest->admin_response): ?>
                <div class="mb-4">
                    <h6><strong>Admin Response:</strong></h6>
                    <div class="border rounded p-3 bg-info text-white">
                        <?php echo nl2br(e($supportRequest->admin_response)); ?>

                        <div class="mt-2">
                            <small>Responded on: <?php echo e($supportRequest->admin_response_at->format('M d, Y H:i')); ?></small>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    Your request is being reviewed by our support team. We will respond as soon as possible.
                </div>
            <?php endif; ?>

            <div class="text-center">
                <a href="<?php echo e(route('support.index')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Submit New Request
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/user/support/show.blade.php ENDPATH**/ ?>