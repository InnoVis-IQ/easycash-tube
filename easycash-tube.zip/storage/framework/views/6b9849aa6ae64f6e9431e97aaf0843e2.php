<?php $__env->startPush('plugin-styles'); ?>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $route = explode('.', Route::currentRouteName());
    ?>
    <div class="nav-container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="<?php echo e(route($route[0] . '.index')); ?>"><?php echo e(ucfirst($route[0])); ?></a></li>
            <a href="<?php echo e(route($route[0] . '.create')); ?>" class="btn btn-sm btn-primary breadcrumb-button"><i
                    class="fa-solid fa-circle-plus"></i> Add</a>
        </ol>
    </div>

    <div class="row">
        <div class="col-lg-4 offset-lg-4 grid-margin stretch-card">
            <div class="card card-statistics">
                <div class="card-header" style="font-weight: bold;">
                    <strong>Account details:</strong>
                </div>
                <div class="card-body">
                    <p>Bank: <?php echo e($banks[0]['bank_name']); ?></p>
                    <p>Account Number: <?php echo e($banks[0]['account_number']); ?></p>
                    <p>IBAN Number: <?php echo e($banks[0]['iban']); ?></p>
                    <p>Account Title: <?php echo e($banks[0]['account_title']); ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-lg-4 offset-lg-4 grid-margin stretch-card">
            <div class="card card-statistics">
                <div class="card-header" style="font-weight: bold;">
                    Please upload deposit slip
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route($route[0] . '.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user" value="<?php echo e(Auth::user()['id']); ?>">
                        <div class="form-group">
                            <label for="bank">Bank *</label>
                            <select name="bank" id="bank" class="form-control" data-placeholder="Select" style="font-size: 14px;" required>
                                <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($bank['id']); ?>">
                                        <?php echo e($bank['bank_name'] . '-' . $bank['account_number'] . ' (' . $bank['account_title'] . ')'); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="amount">Amount *</label>
                            <input type="number" name="amount" min="0" id="amount" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="transaction_id">Transaction ID</label>
                            <input type="text" name="transaction_id" min="0" id="transaction_id" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="date">Date *</label>
                            <input type="date" name="date" id="date" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="proof">Transaction Proof *</label>
                            <input type="file" name="proof" id="proof" class="form-control" required>
                        </div>
                        <div class="form-group text-center">
                            <input type="submit" name="submit" value="submit" class="btn btn-success">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <?php echo Html::script('/assets/plugins/chartjs/chart.min.js'); ?>

    <?php echo Html::script('/assets/plugins/jquery-sparkline/jquery.sparkline.min.js'); ?>

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <?php echo Html::script('/assets/js/dashboard.js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/user/deposit/create.blade.php ENDPATH**/ ?>