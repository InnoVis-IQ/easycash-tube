<nav class="sidebar sidebar-offcanvas dynamic-active-class-disabled" id="sidebar">
    <ul class="nav">
        <li class="nav-item nav-profile not-navigation-link">
            <div class="nav-link">
                <div class="user-wrapper mb-0">
                    <div class="profile-image">
                        <img src="<?php echo e(url('assets/images/faces/face0.png')); ?>" alt="profile image">
                    </div>
                    <div class="text-wrapper">
                        <p class="profile-name"><?php echo e(Auth::user()['name']); ?></p>
                        <div class="dropdown" data-display="static">
                            <a href="#" class="nav-link d-flex user-switch-dropdown-toggler"
                                id="UsersettingsDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                                <small class="designation text-muted">
                                    <?php echo e(ucfirst(strtolower(Auth::user()['role']))); ?>

                                </small>
                                <span class="status-indicator online"></span>
                            </a>
                            
                        </div>
                    </div>
                </div>

                
                
            </div>
        </li>
        <?php if(in_array(strtolower(Auth::user()['role']), ['user'])): ?>
            <div class="row">
                <div class="col-md-10 offset-md-1 text-center mb-2" style="font-weight: bold;">
                    Account Balance:
                    <?php
                        $userAccount = App\Models\UserAccount::where('user_id', Auth::user()['id'])->first();
                        echo $userAccount['net_amount'] . ' PKR';
                    ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 offset-md-1">
                    <a href="<?php echo e(route('deposits.index')); ?>" class="btn btn-primary">Deposit</a>
                </div>
                <div class="col-md-4 offset-md-1">
                    <a href="<?php echo e(route('withdraws.index')); ?>" class="btn btn-warning">Withdraw</a>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-10 offset-md-1 text-center">
                    <a data-toggle="modal" data-target="#referModal" class="btn btn-success text-white">Refer a
                        friend</a>
                </div>
            </div>
        <?php endif; ?>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <i class="fa-solid fa-gauge-high"></i>
                <span class="menu-title pl-2">Dashboard</span>
            </a>
        </li>
        <?php if(in_array(strtolower(Auth::user()['role']), ['superadmin', 'admin'])): ?>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                    <i class="fa-solid fa-users"></i>
                    <span class="menu-title pl-2">Users</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if(in_array(strtolower(Auth::user()['role']), ['superadmin', 'admin'])): ?>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('plans.index')); ?>">
                    <i class="fa-solid fa-compass-drafting"></i>
                    <span class="menu-title pl-2">Plans</span>
                </a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('deposits.index')); ?>">
                    <i class="fa-solid fa-coins"></i>
                    <span class="menu-title pl-2">Deposit Requests</span>
                </a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('withdraws.index')); ?>">
                    <i class="fa-solid fa-coins"></i>
                    <span class="menu-title pl-2">Withdraw Requests</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if(in_array(strtolower(Auth::user()['role']), ['user'])): ?>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('plans.index')); ?>">
                    <i class="fa-solid fa-compass-drafting"></i>
                    <span class="menu-title pl-2">Investment Plans</span>
                </a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('deposits.index')); ?>">
                    <i class="fa-solid fa-coins"></i>
                    <span class="menu-title pl-2">Deposits</span>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>


<!-- Modal -->
<div class="modal fade" id="referModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="mytext"><?php echo e(route('register')); ?>?ref=<?php echo e(Auth::user()['referral_code']); ?></div>
                <div class="text-right">
                    Copy the above referral link and share with your friends to get 15% bonus on first subscription.
                    
                </div>
            </div>
            
        </div>
    </div>
</div>

<script>
    function copyTextFromElement(elementID) {
        let element = document.getElementById(elementID); //select the element
        let elementText = element.textContent; //get the text content from the element
        copyText(elementText); //use the copyText function below
        alert("Referral link copied");
    }

    function copyText(text) {
        navigator.clipboard.writeText(text);
    }
</script>
<?php /**PATH D:\laragon\www\mslifepartner\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>