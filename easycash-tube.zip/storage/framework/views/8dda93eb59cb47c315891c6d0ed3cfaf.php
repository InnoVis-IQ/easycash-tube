<?php $__env->startPush('plugin-styles'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Support Request History</h2>
        <a href="<?php echo e(route('support.index')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> New Request
        </a>
    </div>

    <?php if($supportRequests->count() > 0): ?>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Subject</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $supportRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($request->created_at->format('M d, Y H:i')); ?></td>
                                    <td><?php echo e($request->subject); ?></td>
                                    <td>
                                        <span class="badge bg-info"><?php echo e(ucfirst($request->category)); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($request->status == 'open' ? 'warning' : ($request->status == 'closed' ? 'success' : 'info')); ?>">
                                            <?php echo e(ucfirst($request->status)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('support.show', $request->id)); ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <?php if($request->admin_response): ?>
                                            <a href="<?php echo e(route('support.response', $request->id)); ?>" class="btn btn-sm btn-success">
                                                <i class="fas fa-reply"></i> Response
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body text-center">
                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                <h5>No Support Requests</h5>
                <p class="text-muted">You haven't submitted any support requests yet.</p>
                <a href="<?php echo e(route('support.index')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Submit Your First Request
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/user/support/history.blade.php ENDPATH**/ ?>