<?php echo e($slot); ?>

<?php /**PATH D:\laragon\www\easycash-tube\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>