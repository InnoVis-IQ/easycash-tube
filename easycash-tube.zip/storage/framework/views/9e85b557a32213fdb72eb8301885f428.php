<?php $__env->startPush('plugin-styles'); ?>
    
    
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/rowreorder/1.3.3/css/rowReorder.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $route = explode('.', Route::currentRouteName());
    ?>
    <div class="nav-container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="<?php echo e(route($route[0].'.index')); ?>"><?php echo e(ucfirst($route[0])); ?></a></li>
            <a href="<?php echo e(route($route[0].'.create')); ?>" class="btn btn-sm btn-primary breadcrumb-button"><i class="fa-solid fa-circle-plus"></i> Add</a>
        </ol>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 style="font-weight: bold;">Investment Plans</h4>
        </div>
        <div class="card-body">
            <table class="table" id="responsive-datatables">
                <thead>
                    <tr>
                        <th>Sr</th>
                        <th>Plan</th>
                        <th>Amount</th>
                        <th>Daily Profit</th>
                        <th>Total Profit</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Auth::user()['role'] != 'SUPERADMIN' && in_array($item['role'], ['SUPERADMIN', 'ADMIN'])): ?>
                            <?php continue; ?>
                        <?php endif; ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item['title']); ?></td>
                            <td><?php echo e($item['amount']); ?></td>
                            <td><?php echo e($item['daily_profit']); ?></td>
                            <td><?php echo e($item['total_profit']); ?></td>
                            <td><?php echo e($item['status']); ?></td>
                            <td>
                                <?php echo actionButtons($item); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <?php echo Html::script('/assets/plugins/chartjs/chart.min.js'); ?>

    <?php echo Html::script('/assets/plugins/jquery-sparkline/jquery.sparkline.min.js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
   <script type="text/javascript" src="https://cdn.datatables.net/rowreorder/1.3.3/js/dataTables.rowReorder.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js"></script>
    <?php echo Html::script('/assets/js/dashboard.js'); ?>

    
    <script>
        
        $(document).ready(function() {
            var table = $('#responsive-datatables').DataTable( {
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true
            } );
        } );
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\mslifepartner\resources\views/backend/admin/investmentPlans/index.blade.php ENDPATH**/ ?>