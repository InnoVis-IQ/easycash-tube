<?php $__env->startPush('plugin-styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $route = explode('.', Route::currentRouteName());
    ?>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('message')); ?>

            
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="nav-container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="<?php echo e(route($route[0].'.index')); ?>"><?php echo e(ucfirst($route[0])); ?></a></li>
        </ol>
    </div>

    <div class="row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card my-3">
                    <div class="card-header p-0">
                        <div class="text-center bg-info text-white" style="font-weight: bold; line-height: 3;">
                            <?php echo e($item['title']); ?></div>
                        <div class="px-4 py-2">
                            <div style="float: left; text-align: center;">
                                <span style="font-size: 24px; font-weight: bold;">
                                    <?php echo e($item['daily_profit']); ?> PKR
                                </span>
                                <br>
                                <small>Daily Interest</small>
                            </div>
                            <div style="float: right; text-align: center;">
                                <span style="font-size: 24px; font-weight: bold;">
                                    <?php echo e($item['plan_days']); ?>

                                </span>
                                <br>
                                <small>Plan Days</small>
                            </div>
                        </div>
                    </div>
                    <div class="card-body py-0">
                        <div class="row my-3">
                            <div class="col-6">
                                Initial Deposit:
                            </div>
                            <div class="col-6 text-right">
                                <?php echo e($item['amount']); ?> PKR
                            </div>
                        </div>
                        <div class="row my-3">
                            <div class="col-6">
                                Daily Interest:
                            </div>
                            <div class="col-6 text-right">
                                <?php echo e($item['daily_profit']); ?> PKR
                            </div>
                        </div>
                        <div class="row my-3">
                            <div class="col-6">
                                Plan Duration:
                            </div>
                            <div class="col-6 text-right">
                                <?php echo e($item['plan_days']); ?> PKR
                            </div>
                        </div>
                        <div class="row my-3">
                            <div class="col-6">
                                Total Return:
                            </div>
                            <div class="col-6 text-right">
                                <?php echo e($item['total_profit']); ?> PKR
                            </div>
                        </div>
                        <div class="row my-3 text-center">
                            <div class="col-12">
                                <form action="<?php echo e(route('userSubscriptions.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="user" value="<?php echo e(Auth::user()['id']); ?>">
                                    <button class="btn btn-primary" name="invest" value="<?php echo e($item['id']); ?>">
                                        Invest Now
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/user/investmentPlans/create.blade.php ENDPATH**/ ?>