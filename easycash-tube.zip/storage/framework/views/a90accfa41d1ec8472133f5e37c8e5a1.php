<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Easycash Tube | Watch. Earn. Repeat.</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .hero-section {
            background: linear-gradient(to bottom, rgba(0,0,0,0.6), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1595433707802-163de4bfc94b') no-repeat center center/cover;
            color: #fff;
            padding: 120px 0;
            text-align: center;
        }

        .hero-section h1 {
            font-size: 3rem;
            font-weight: 700;
        }

        .hero-section p {
            font-size: 1.25rem;
        }

        .card:hover {
            transform: translateY(-5px);
            transition: 0.3s;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }

        .icon-box {
            font-size: 2.5rem;
            color: #28a745;
        }

        .section-title {
            font-weight: 600;
            font-size: 2rem;
            margin-bottom: 2rem;
        }

        .gradient-bg {
            background: linear-gradient(90deg, #28a745 0%, #007bff 100%);
            color: #fff;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Easycash Tube</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbar">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="#hero">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#plans">Plans</a></li>
                <li class="nav-item"><a class="nav-link" href="#faq">FAQ</a></li>
                <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
            </ul>
            <div>
                <a href="<?php echo e(url('/register')); ?>" class="btn btn-success me-2">Get Started</a>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary">Login</a>
            </div>
        </div>
    </div>
</nav>

<!-- Hero -->
<section class="hero-section" id="hero">
    <div class="container">
        <h1>Earn Daily Just by Watching Videos!</h1>
        <p class="my-4">Join Easycash Tube and earn up to 20% daily on your selected plan by watching just 1 video a day.</p>
        <a href="<?php echo e(url('/register')); ?>" class="btn btn-success btn-lg me-3">Join Now</a>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light btn-lg">Login</a>
    </div>
</section>

<!-- How It Works -->
<section class="py-5 bg-light text-center" id="how-it-works">
    <div class="container">
        <h2 class="section-title">How It Works</h2>
        <div class="row g-4">
            <div class="col-md-3">
                <div class="icon-box mb-3"><i class="bi bi-cash-coin"></i></div>
                <h5>Choose a Plan</h5>
                <p>Start with as low as Rs. 500</p>
            </div>
            <div class="col-md-3">
                <div class="icon-box mb-3"><i class="bi bi-play-circle"></i></div>
                <h5>Watch a Video</h5>
                <p>1 video daily for 5 days</p>
            </div>
            <div class="col-md-3">
                <div class="icon-box mb-3"><i class="bi bi-graph-up"></i></div>
                <h5>Earn Instantly</h5>
                <p>Up to 10% return per day</p>
            </div>
            <div class="col-md-3">
                <div class="icon-box mb-3"><i class="bi bi-wallet2"></i></div>
                <h5>Withdraw Easily</h5>
                <p>Via Easypaisa, JazzCash, NayaPay</p>
            </div>
        </div>
    </div>
</section>

<!-- Plans -->
<section class="py-5" id="plans">
    <div class="container text-center">
        <h2 class="section-title">Investment Plans</h2>
        <div class="row g-4">
            <?php
                $plans = [
                    ['name' => 'Starter', 'price' => 500, 'daily' => 50, 'total' => 250],
                    ['name' => 'Bronze', 'price' => 2000, 'daily' => 200, 'total' => 1000],
                    ['name' => 'Silver', 'price' => 6000, 'daily' => 600, 'total' => 3000],
                    ['name' => 'Gold', 'price' => 12000, 'daily' => 1200, 'total' => 6000],
                    ['name' => 'Diamond', 'price' => 25000, 'daily' => 2500, 'total' => 12500],
                ];
            ?>
            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($plan['name']); ?> Plan</h5>
                        <p class="card-text">Price: Rs. <?php echo e($plan['price']); ?></p>
                        <p>Daily Earning: Rs. <?php echo e($plan['daily']); ?></p>
                        <p>Total in 5 Days: Rs. <?php echo e($plan['total']); ?></p>
                        <span class="badge bg-secondary">Only Once</span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Why Choose Us -->
<section class="py-5 gradient-bg text-center">
    <div class="container">
        <h2 class="section-title text-white">Why Choose Easycash Tube?</h2>
        <div class="row">
            <div class="col-md-6 text-start mx-auto">
                <ul class="list-group list-group-flush text-white">
                    <li class="list-group-item bg-transparent border-white">✅ Simple and fast income method</li>
                    <li class="list-group-item bg-transparent border-white">✅ No technical skills needed</li>
                    <li class="list-group-item bg-transparent border-white">✅ Watch anywhere, anytime</li>
                    <li class="list-group-item bg-transparent border-white">✅ Fast payments via Easypaisa, JazzCash, NayaPay</li>
                    <li class="list-group-item bg-transparent border-white">✅ Reinvest easily after 5 days</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- FAQ -->
<section class="py-5 bg-light" id="faq">
    <div class="container">
        <h2 class="section-title text-center">Frequently Asked Questions</h2>
        <div class="accordion" id="faqAccordion">
            <?php
                $faqs = [
                    ['q' => 'What is Easycash Tube?', 'a' => 'It’s a video-based earning platform.'],
                    ['q' => 'How do I earn?', 'a' => 'Pick a plan, watch 1 video per day, earn 10% daily.'],
                    ['q' => 'What plans are available?', 'a' => 'Starter, Bronze, Silver, Gold, Diamond.'],
                    ['q' => 'How long does a plan last?', 'a' => '7 days (5 earning + 2 buffer).'],
                    ['q' => 'How can I withdraw?', 'a' => 'Via Easypaisa, JazzCash, or NayaPay.'],
                ];
            ?>
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="accordion-item">
                <h2 class="accordion-header" id="faqHeading<?php echo e($index); ?>">
                    <button class="accordion-button <?php echo e($index > 0 ? 'collapsed' : ''); ?>" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapse<?php echo e($index); ?>">
                        <?php echo e($faq['q']); ?>

                    </button>
                </h2>
                <div id="faqCollapse<?php echo e($index); ?>" class="accordion-collapse collapse <?php echo e($index == 0 ? 'show' : ''); ?>" data-bs-parent="#faqAccordion">
                    <div class="accordion-body"><?php echo e($faq['a']); ?></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- About -->
<section class="py-5 text-center" id="about">
    <div class="container">
        <h2 class="section-title">About Easycash Tube</h2>
        <p class="lead">We are a smart earning platform built for everyday people in Pakistan. Watch videos, earn daily — all in a few minutes. Transparent. Simple. Secure.</p>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-4" id="contact">
    <div class="container">
        <p>
            <a href="#" class="text-white me-3">Terms & Conditions</a>
            <a href="#" class="text-white me-3">Privacy Policy</a>
            <a href="mailto:support@easycashtube.com" class="text-white">Contact</a>
        </p>
        <p class="mb-0">© 2025 Easycash Tube. All rights reserved.</p>
    </div>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\laragon\www\easycash-tube\resources\views/frontend/web/index2.blade.php ENDPATH**/ ?>