<?php $__env->startPush('style'); ?>
<style>
    .custom-video-modal {
        max-width: 900px;
    }
    .custom-video-modal .modal-content,
    .custom-video-modal .modal-body {
        height: 600px;
        min-height: 400px !important;
    }
    .custom-video-modal .modal-content {
        border-radius: 10px;
    }
    .custom-video-modal .modal-header {
        border-bottom: none;
    }
    .custom-video-modal .modal-footer {
    }
    #videoUrl {
        height: 100% !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Watch & Earn</h2>
    <div class="mb-4">
        <h5>Daily Progress</h5>
        <div class="progress" style="height: 25px;">
            <div class="progress-bar bg-info" role="progressbar" style="width: <?php echo e($totalPlanDays > 0 ? round(($daysWatched/$totalPlanDays)*100) : 0); ?>%" aria-valuenow="<?php echo e($daysWatched); ?>" aria-valuemin="0" aria-valuemax="<?php echo e($totalPlanDays); ?>">
                <?php echo e($daysWatched); ?> / <?php echo e($totalPlanDays); ?> days
            </div>
        </div>
    </div>
    <?php if($watchedToday): ?>
        <div class="alert alert-success">
            You have already watched your video for today. Come back tomorrow for the next one!
        </div>
    <?php else: ?>
        <h3>Available Videos</h3>
        <div class="row">
            <?php
                $unWatched = $videos->whereNotIn('id', $watchedVideos);
            ?>
            <?php $__empty_1 = true; $__currentLoopData = $unWatched; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 video-card"
                         data-title="<?php echo e($video->title); ?>"
                         data-url="<?php echo e($video->video_url); ?>"
                         data-video-id="<?php echo e($video->id); ?>"
                         style="cursor:pointer;">
                        <?php if($video->video_thumbnail): ?>
                            <img src="<?php echo e(asset($video->video_thumbnail)); ?>" class="card-img-top" alt="Thumbnail">
                        <?php else: ?>
                            <div class="d-flex justify-content-center align-items-center" style="height:200px;background:#f5f5f5;">
                                <img src="<?php echo e(asset('assets/images/product_images/watch.jpeg')); ?>" alt="Plan Icon" style="height:80px;">
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($video->title); ?></h5>
                            <p class="card-text"><?php echo e($video->description); ?></p>
                            <span class="badge bg-secondary">Not Watched</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <p>No videos available for your plan.</p>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <h3 class="mt-5">Watched Videos</h3>
    <div class="row">
        <?php
            $watched = $videos->whereIn('id', $watchedVideos);
        ?>
        <?php $__empty_1 = true; $__currentLoopData = $watched; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100 border-success video-card"
                     data-title="<?php echo e($video->title); ?>"
                     data-url="<?php echo e($video->video_url); ?>"
                     data-video-id="<?php echo e($video->id); ?>"
                     style="cursor:pointer;">
                    <?php if($video->video_thumbnail): ?>
                        <img src="<?php echo e(asset($video->video_thumbnail)); ?>" class="card-img-top" alt="Thumbnail">
                    <?php else: ?>
                        <div class="d-flex justify-content-center align-items-center" style="height:200px;background:#f5f5f5;">
                            <img src="<?php echo e(asset('assets/images/product_images/watch.jpeg')); ?>" alt="Plan Icon" style="height:80px;">
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($video->title); ?></h5>
                        <p class="card-text"><?php echo e($video->description); ?></p>
                        <span class="badge bg-success">Watched</span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <p>You have not watched any videos yet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Video Modal -->
<div class="modal fade" id="videoModal" tabindex="-1" aria-labelledby="videoModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg custom-video-modal">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="videoModalLabel">Video Title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="videoUrl" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 10;"></div>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
// YouTube iframe API
var tag = document.createElement('script');
tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

var player;
var currentVideoId;
var currentVideoCard;

function onYouTubeIframeAPIReady() {
    // This function will be called when the YouTube API is ready
}

function createYouTubePlayer(videoUrl, videoId, videoCard) {
    console.log('Creating YouTube player for:', videoUrl, 'Video ID:', videoId);
    
    // Extract video ID from YouTube URL
    var videoIdFromUrl = extractVideoId(videoUrl);
    if (!videoIdFromUrl) {
        console.error('Invalid YouTube URL:', videoUrl);
        return;
    }
    
    console.log('Extracted YouTube video ID:', videoIdFromUrl);

    currentVideoId = videoId;
    currentVideoCard = videoCard;

    // Create YouTube player
    player = new YT.Player('videoUrl', {
        height: '100%',
        width: '100%',
        videoId: videoIdFromUrl,
        playerVars: {
            'autoplay': 1,
            'controls': 1,
            'rel': 0,
            'showinfo': 0,
            'modestbranding': 1
        },
        events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange
        }
    });
    
    console.log('YouTube player created');
}

function extractVideoId(url) {
    var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    var match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
}

function onPlayerReady(event) {
    console.log('YouTube player is ready');
}

function onPlayerStateChange(event) {
    console.log('Player state changed:', event.data);
    // Check if video has ended (state 0 = ended)
    if (event.data === YT.PlayerState.ENDED) {
        console.log('Video ended, marking as watched for video ID:', currentVideoId);
        markVideoAsWatched(currentVideoId, currentVideoCard);
    }
}

function markVideoAsWatched(videoId, videoCard) {
    console.log('Attempting to mark video as watched:', videoId);
    
    // Get CSRF token
    var csrfToken = document.querySelector('meta[name="_token"]').getAttribute('content');
    console.log('CSRF Token:', csrfToken);
    
    // Send AJAX request to mark video as watched
    fetch('<?php echo e(route("videos.mark-watched")); ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken
        },
        body: JSON.stringify({
            video_id: videoId
        })
    })
    .then(response => {
        console.log('Response status:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data);
        if (data.success) {
            // Update the UI to show video as watched
            updateVideoCardStatus(videoCard, true);
            console.log('Video marked as watched:', data.message);
        } else {
            console.error('Error marking video as watched:', data.message);
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
    });
}

function updateVideoCardStatus(videoCard, isWatched) {
    if (isWatched) {
        // Update badge to show watched status
        var badge = videoCard.querySelector('.badge');
        if (badge) {
            badge.className = 'badge bg-success';
            badge.textContent = 'Watched';
        }
        
        // Add border-success class to card
        videoCard.classList.add('border-success');
    }
}

document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.video-card').forEach(function(card) {
        card.addEventListener('click', function() {
            var title = this.getAttribute('data-title');
            var url = this.getAttribute('data-url');
            var videoId = this.getAttribute('data-video-id');
            
            document.getElementById('videoModalLabel').textContent = title;
            
            // Clear previous iframe content
            var iframe = document.getElementById('videoUrl');
            iframe.innerHTML = '';
            
            // Create YouTube player
            createYouTubePlayer(url, videoId, this);
            
            var videoModal = new bootstrap.Modal(document.getElementById('videoModal'));
            videoModal.show();
            
            // Add a manual button for testing (temporary)
            setTimeout(function() {
                if (document.querySelector('.manual-mark-btn')) {
                    document.querySelector('.manual-mark-btn').remove();
                }
                var manualBtn = document.createElement('button');
                manualBtn.className = 'btn btn-warning manual-mark-btn';
                manualBtn.textContent = 'Mark as Watched (Manual)';
                manualBtn.style.position = 'absolute';
                manualBtn.style.top = '10px';
                manualBtn.style.right = '10px';
                manualBtn.style.zIndex = '1000';
                manualBtn.onclick = function() {
                    markVideoAsWatched(videoId, this.closest('.video-card'));
                };
                document.querySelector('.modal-content').appendChild(manualBtn);
            }, 2000);
        });
    });

    // Clean up player when modal is closed
    document.getElementById('videoModal').addEventListener('hidden.bs.modal', function () {
        if (player && typeof player.destroy === 'function') {
            player.destroy();
        }
        // Clear the video container
        document.getElementById('videoUrl').innerHTML = '';
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/user/videos/watch.blade.php ENDPATH**/ ?>