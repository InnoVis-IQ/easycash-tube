<?php $__env->startPush('plugin-styles'); ?>
    

    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/rowreorder/1.3.3/css/rowReorder.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $route = explode('.', Route::currentRouteName());
    ?>
    <div class="nav-container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="<?php echo e(route($route[0] . '.index')); ?>"><?php echo e(ucfirst($route[0])); ?></a></li>
            
        </ol>
    </div>

    <div class="row">
        <div class="col-12 col-md-6 mx-auto  stretch-card mb-4">
            <div class="card card-statistics">
                <div class="card-body">
                    <div
                        class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
                        <div class="float-left">
                            <i class="fa-solid fa-coins fa-2xl"></i>
                        </div>
                        <div class="float-right">
                            <p class="mb-0 text-right">Pending Approval</p>
                            <div class="fluid-container">
                                <h3 class="font-weight-medium text-right mb-0"><?php echo e($pending); ?></h3>
                                <p class="mb-0 text-right"> request(s)</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 style="font-weight: bold;">Withdraw History</h4>
        </div>
        <div class="card-body">
            <table class="table " id="responsive-datatables">
                <thead>
                    <tr>
                        <th>Sr</th>
                        <th>User</th>
                        <th>Account Balance</th>
                        <th>Amount</th>
                        <th>Account Detail</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Auth::user()['role'] != 'SUPERADMIN' && in_array($item['role'], ['SUPERADMIN', 'ADMIN'])): ?>
                            <?php continue; ?>
                        <?php endif; ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($item['user']['name']); ?></td>
                            <td><?php echo $item['status'] == 'requested' ? $accountBalance[$item['user_id']] : 'Account Updated<br>after Withdrawal'; ?></td>
                            <td><?php echo e($item['amount']); ?></td>
                            <td><?php echo e($item['user_bank']['account_number']); ?><br><?php echo e($item['user_bank']['account_title']); ?></td>
                            <td><?php echo e(date('d-M-Y', strtotime($item['created_at']))); ?></td>
                            <td><?php echo e($item['status']); ?></td>
                            <td>
                                <?php if($item['status'] == 'requested'): ?>
                                    <a href="" data-toggle="modal" data-target="#action<?php echo e($key); ?>"
                                        class="btn btn-success"><i class='fa-regular fa-circle-check'></i> Transferred</a>
                                    
                                <?php else: ?>
                                    
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal -->
        <div class="modal fade" id="action<?php echo e($key); ?>" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class='fa-regular fa-circle-check'></i> Tranferred
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(route($route[0] . '.update', $item['id'])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>

                            <div class="form-group">
                                <label for="bank">Transferred from Bank *</label>
                                <select name="bank" id="bank" class="form-control" data-placeholder="Select"
                                    style="font-size: 14px;" required>
                                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bank['id']); ?>">
                                            <?php echo e($bank['bank_name'] . '-' . $bank['account_number'] . ' (' . $bank['account_title'] . ')'); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" name="status" value="transferred" class="btn btn-success"><i
                                    class='fa-regular fa-circle-check'></i>
                                Transferred</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <?php echo Html::script('/assets/plugins/chartjs/chart.min.js'); ?>

    <?php echo Html::script('/assets/plugins/jquery-sparkline/jquery.sparkline.min.js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script type="text/javascript" src="https://cdn.datatables.net/rowreorder/1.3.3/js/dataTables.rowReorder.min.js">
    </script>
    <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js">
    </script>
    <?php echo Html::script('/assets/js/dashboard.js'); ?>


    <script>
        $(document).ready(function() {
            var table = $('#responsive-datatables').DataTable({
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/admin/withdraw/index.blade.php ENDPATH**/ ?>