<footer class="footer">
  <div class="container-fluid clearfix">
    <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright ©  <a href="http://www.mslifepartner.com/" target="_blank">msLifePartner.com</a> 2023</span>
    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Created by <a href="#" target="_blank">Dev End Solutions</a>
    </span>
  </div>
</footer>
<?php /**PATH D:\laragon\www\mslifepartner\resources\views/layout/footer.blade.php ENDPATH**/ ?>