

<?php $__env->startPush('plugin-styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $route = explode('.', Route::currentRouteName());
    ?>
    <div class="nav-container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="<?php echo e(route($route[0].'.index')); ?>"><?php echo e(ucfirst($route[0])); ?></a></li>
        </ol>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 style="font-weight: bold;">Edit Video</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route($route[0].'.update', $video->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="form-group mb-3">
                            <label for="plan_id">Investment Plan *</label>
                            <select class="form-control" id="plan_id" name="plan_id" required>
                                <option value="">Select Plan</option>
                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($plan->id); ?>" <?php echo e(old('plan_id', $video->plan_id) == $plan->id ? 'selected' : ''); ?>><?php echo e($plan->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="title">Title *</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title', $video->title)); ?>" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="description">Description</label>
                            <input type="text" class="form-control" id="description" name="description" value="<?php echo e(old('description', $video->description)); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="video_url">Video URL *</label>
                            <input type="text" class="form-control" id="video_url" name="video_url" value="<?php echo e(old('video_url', $video->video_url)); ?>" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="video_thumbnail">Video Thumbnail</label>
                            <input type="text" class="form-control" id="video_thumbnail" name="video_thumbnail" value="<?php echo e(old('video_thumbnail', $video->video_thumbnail)); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="expiry_date">Expiry Date</label>
                            <input type="date" class="form-control" id="expiry_date" name="expiry_date" value="<?php echo e(old('expiry_date', $video->expiry_date ? \Carbon\Carbon::parse($video->expiry_date)->format('Y-m-d') : '')); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label for="status">Status</label>
                            <select class="form-control" id="status" name="status">
                                <option value="active" <?php echo e(old('status', $video->status) == 'active' ? 'selected' : ''); ?>>Active</option>
                                <option value="inactive" <?php echo e(old('status', $video->status) == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Video</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/admin/videos/edit.blade.php ENDPATH**/ ?>