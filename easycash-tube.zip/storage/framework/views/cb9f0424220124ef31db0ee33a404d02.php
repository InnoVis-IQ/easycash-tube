

<?php $__env->startPush('plugin-styles'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Support & Help</h2>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Quick Contact -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-phone fa-2x text-primary mb-3"></i>
                    <h5>Phone Support</h5>
                    <p class="mb-0">+92 300 1234567</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fab fa-whatsapp fa-2x text-success mb-3"></i>
                    <h5>WhatsApp Support</h5>
                    <a href="https://wa.me/923001234567" target="_blank" class="btn btn-success btn-sm">
                        <i class="fab fa-whatsapp"></i> Chat Now
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-envelope fa-2x text-info mb-3"></i>
                    <h5>Email Support</h5>
                    <p class="mb-0">support@easycashtube.com</p>
                </div>
            </div>
        </div>
    </div>

    <!-- FAQs Section -->
    <div class="card mb-4 shadow-sm faq-modern-card">
        <div class="card-header bg-white border-0 pb-0">
            <h4 class="fw-bold mb-0"><i class="fas fa-question-circle me-2"></i> Frequently Asked Questions</h4>
        </div>
        <div class="card-body">
            <?php if($faqs->count() > 0): ?>
                <div class="accordion faq-modern-accordion" id="faqAccordion">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item faq-modern-item mb-2">
                            <h2 class="accordion-header" id="faq<?php echo e($index); ?>">
                                <button class="accordion-button faq-modern-question d-flex align-items-center <?php echo e($index > 0 ? 'collapsed' : ''); ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($index); ?>" aria-expanded="<?php echo e($index === 0 ? 'true' : 'false'); ?>" aria-controls="collapse<?php echo e($index); ?>">
                                    <span class="me-2 text-primary"><i class="fas fa-chevron-down faq-chevron"></i></span>
                                    <span class="flex-grow-1"><?php echo e($faq->question); ?></span>
                                    <?php if($faq->category): ?>
                                        <span class="badge bg-info text-dark ms-2"><?php echo e(ucfirst($faq->category)); ?></span>
                                    <?php endif; ?>
                                </button>
                            </h2>
                            <div id="collapse<?php echo e($index); ?>" class="accordion-collapse collapse <?php echo e($index === 0 ? 'show' : ''); ?>" aria-labelledby="faq<?php echo e($index); ?>" data-bs-parent="#faqAccordion">
                                <div class="accordion-body faq-modern-answer">
                                    <?php echo nl2br(e($faq->answer)); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="text-muted text-center">No FAQs available at the moment.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Contact Form -->
    <div class="card">
        <div class="card-header">
            <h4><i class="fas fa-envelope"></i> Submit Support Request</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('support.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group mb-3">
                            <label for="subject">Subject *</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="subject" name="subject" value="<?php echo e(old('subject')); ?>" required>
                            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group mb-3">
                            <label for="category">Category *</label>
                            <select class="form-control <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="category" name="category" required>
                                <option value="">Select Category</option>
                                <option value="general" <?php echo e(old('category') == 'general' ? 'selected' : ''); ?>>General</option>
                                <option value="technical" <?php echo e(old('category') == 'technical' ? 'selected' : ''); ?>>Technical</option>
                                <option value="payment" <?php echo e(old('category') == 'payment' ? 'selected' : ''); ?>>Payment</option>
                                <option value="withdrawal" <?php echo e(old('category') == 'withdrawal' ? 'selected' : ''); ?>>Withdrawal</option>
                                <option value="other" <?php echo e(old('category') == 'other' ? 'selected' : ''); ?>>Other</option>
                            </select>
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group mb-3">
                            <label for="priority">Priority *</label>
                            <select class="form-control <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="priority" name="priority" required>
                                <option value="">Select Priority</option>
                                <option value="low" <?php echo e(old('priority') == 'low' ? 'selected' : ''); ?>>Low</option>
                                <option value="medium" <?php echo e(old('priority') == 'medium' ? 'selected' : ''); ?>>Medium</option>
                                <option value="high" <?php echo e(old('priority') == 'high' ? 'selected' : ''); ?>>High</option>
                            </select>
                            <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label for="message">Message *</label>
                    <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="message" name="message" rows="5" placeholder="Please describe your issue in detail..." required><?php echo e(old('message')); ?></textarea>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Submit Request
                    </button>
                    <a href="<?php echo e(route('support.history')); ?>" class="btn btn-secondary">
                        <i class="fas fa-history"></i> View History
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<style>
.faq-modern-card {
    background: #f8fafc;
    border-radius: 1rem;
    border: none;
}
.faq-modern-accordion .faq-modern-item {
    border: none;
    background: transparent;
}
.faq-modern-question {
    background: #fff;
    border-radius: 0.5rem;
    font-size: 1.08rem;
    font-weight: 500;
    color: #222;
    box-shadow: 0 1px 4px rgba(0,0,0,0.04);
    transition: background 0.2s, box-shadow 0.2s;
    padding: 1rem 1.25rem;
}
.faq-modern-question:hover, .faq-modern-question:not(.collapsed) {
    background: #e9f5ff;
    color: #0d6efd;
    box-shadow: 0 2px 8px rgba(13,110,253,0.08);
}
.faq-modern-question .faq-chevron {
    transition: transform 0.3s;
}
.faq-modern-question:not(.collapsed) .faq-chevron {
    transform: rotate(180deg);
}
.faq-modern-answer {
    background: #fff;
    border-radius: 0.5rem;
    margin-top: 0.5rem;
    padding: 1rem 1.25rem;
    font-size: 1rem;
    color: #444;
    box-shadow: 0 1px 4px rgba(0,0,0,0.03);
}
.badge.bg-info.text-dark {
    background: #d1ecf1 !important;
    color: #0c5460 !important;
    font-size: 0.85em;
    font-weight: 500;
}
</style>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/user/support/index.blade.php ENDPATH**/ ?>