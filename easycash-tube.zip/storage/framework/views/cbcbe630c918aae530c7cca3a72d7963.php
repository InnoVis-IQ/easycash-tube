

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Support Requests</h3>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Subject</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $supportRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>#<?php echo e($request->id); ?></td>
                                        <td><?php echo e($request->user->name ?? 'N/A'); ?></td>
                                        <td><?php echo e(Str::limit($request->subject, 50)); ?></td>
                                        <td>
                                            <span class="badge badge-info"><?php echo e(ucfirst($request->category)); ?></span>
                                        </td>
                                        <td>
                                            <?php switch($request->status):
                                                case ('open'): ?>
                                                    <span class="badge badge-warning">Open</span>
                                                    <?php break; ?>
                                                <?php case ('in_progress'): ?>
                                                    <span class="badge badge-primary">In Progress</span>
                                                    <?php break; ?>
                                                <?php case ('resolved'): ?>
                                                    <span class="badge badge-success">Resolved</span>
                                                    <?php break; ?>
                                                <?php case ('closed'): ?>
                                                    <span class="badge badge-secondary">Closed</span>
                                                    <?php break; ?>
                                                <?php default: ?>
                                                    <span class="badge badge-light"><?php echo e(ucfirst($request->status)); ?></span>
                                            <?php endswitch; ?>
                                        </td>
                                        <td><?php echo e($request->created_at->format('M d, Y H:i')); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.support.show', $request->id)); ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            <?php if($request->status !== 'closed'): ?>
                                                <form action="<?php echo e(route('admin.support.close', $request->id)); ?>" 
                                                      method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-sm btn-secondary" 
                                                            onclick="return confirm('Are you sure you want to close this request?')">
                                                        <i class="fas fa-times"></i> Close
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No support requests found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-center">
                        <?php echo e($supportRequests->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/admin/support/index.blade.php ENDPATH**/ ?>