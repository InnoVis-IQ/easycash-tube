

<?php $__env->startPush('plugin-styles'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/rowreorder/1.3.3/css/rowReorder.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $route = explode('.', Route::currentRouteName());
    ?>
    <div class="nav-container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="<?php echo e(route($route[0].'.index')); ?>"><?php echo e(ucfirst($route[0])); ?></a></li>
            <a href="<?php echo e(route($route[0].'.create')); ?>" class="btn btn-sm btn-primary breadcrumb-button"><i class="fa-solid fa-circle-plus"></i> Add</a>
        </ol>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 style="font-weight: bold;">Videos</h4>
        </div>
        <div class="card-body">
            <table class="table" id="responsive-datatables">
                <thead>
                    <tr>
                        <th>Sr</th>
                        <th>Plan</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Video (Views)</th>
                        <th>Video Thumbnail</th>
                        <th>Expiry Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="<?php echo e($item['deleted_at'] ? 'bg-secondary' : ''); ?>"><?php echo e($key + 1); ?></td>
                            <td class="<?php echo e($item['deleted_at'] ? 'bg-secondary' : ''); ?>"><?php echo e($item->plan->title); ?></td>
                            <td class="<?php echo e($item['deleted_at'] ? 'bg-secondary' : ''); ?>"><?php echo e($item->title); ?></td>
                            <td class="<?php echo e($item['deleted_at'] ? 'bg-secondary' : ''); ?>"><?php echo e($item->description); ?></td>
                            <td class="<?php echo e($item['deleted_at'] ? 'bg-secondary' : ''); ?>"><a href="<?php echo e($item->video_url); ?>" target="_blank">View</a> (<?php echo e($videoWatchCounts[$item->id] ?? 0); ?>)</td>
                            <td class="<?php echo e($item['deleted_at'] ? 'bg-secondary' : ''); ?>">
                                <?php if($item->video_thumbnail): ?>
                                    <img src="<?php echo e($item->video_thumbnail); ?>" alt="Thumbnail" style="max-width: 80px; max-height: 50px;">
                                <?php endif; ?>
                            </td>
                            <td class="<?php echo e($item['deleted_at'] ? 'bg-secondary' : ''); ?>"><?php echo e($item->expiry_date ? \Carbon\Carbon::parse($item->expiry_date)->format('Y-m-d') : ''); ?></td>
                            <td class="<?php echo e($item['deleted_at'] ? 'bg-secondary' : ''); ?>"><?php echo e($item->status); ?></td>
                            <td class="<?php echo e($item['deleted_at'] ? 'bg-secondary' : ''); ?>">
                                <a href="<?php echo e(route($route[0].'.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <form action="<?php echo e(route($route[0].'.destroy', $item->id)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <?php echo Html::script('/assets/plugins/chartjs/chart.min.js'); ?>

    <?php echo Html::script('/assets/plugins/jquery-sparkline/jquery.sparkline.min.js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
   <script type="text/javascript" src="https://cdn.datatables.net/rowreorder/1.3.3/js/dataTables.rowReorder.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js"></script>
    <?php echo Html::script('/assets/js/dashboard.js'); ?>

    <script>
        $(document).ready(function() {
            var table = $('#responsive-datatables').DataTable( {
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true
            } );
        } );
    </script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/admin/videos/index.blade.php ENDPATH**/ ?>