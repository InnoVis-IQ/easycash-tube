<?php $__env->startPush('plugin-styles'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <h5>Admin Dashboard</h5>
        </div>
    </div>
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info">
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    
    <!-- Main Statistics Cards -->
    <div class="row">
        <div class="col-md-3 col-sm-6 grid-margin stretch-card">
            <div class="card card-statistics">
                <a href="<?php echo e(route('users.index')); ?>">
                    <div class="card-body">
                        <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
                            <div class="float-left">
                                <i class="fa-solid fa-users fa-2xl" style="color: #28a745;"></i>
                            </div>
                            <div class="float-right">
                                <p class="mb-0 text-right">Total Users</p>
                                <div class="fluid-container">
                                    <h3 class="font-weight-medium text-right mb-0"><?php echo e($totalUsers); ?></h3>
                                </div>
                            </div>
                        </div>
                        <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
                            Active: <?php echo e($totalActiveUsers); ?>

                        </p>
                    </div>
                </a>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-6 grid-margin stretch-card">
            <div class="card card-statistics">
                <a href="<?php echo e(route('deposits.index')); ?>">
                    <div class="card-body">
                        <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
                            <div class="float-left">
                                <i class="fa-solid fa-hand-holding-dollar fa-2xl" style="color: #007bff;"></i>
                            </div>
                            <div class="float-right">
                                <p class="mb-0 text-right">Pending Deposits</p>
                                <div class="fluid-container">
                                    <h3 class="font-weight-medium text-right mb-0"><?php echo e($pendingDeposits); ?></h3>
                                </div>
                            </div>
                        </div>
                        <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
                            Awaiting approval
                        </p>
                    </div>
                </a>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-6 grid-margin stretch-card">
            <div class="card card-statistics">
                <a href="<?php echo e(route('withdraws.index')); ?>">
                    <div class="card-body">
                        <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
                            <div class="float-left">
                                <i class="fa-solid fa-money-bill-transfer fa-2xl" style="color: #dc3545;"></i>
                            </div>
                            <div class="float-right">
                                <p class="mb-0 text-right">Pending Withdrawals</p>
                                <div class="fluid-container">
                                    <h3 class="font-weight-medium text-right mb-0"><?php echo e($pendingWithdrawals); ?></h3>
                                </div>
                            </div>
                        </div>
                        <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
                            Total: <?php echo e($totalWithdrawals); ?> | Completed: <?php echo e($completedWithdrawals); ?>

                        </p>
                    </div>
                </a>
            </div>
        </div>
        
        <div class="col-md-3 col-sm-6 grid-margin stretch-card">
            <div class="card card-statistics">
                <div class="card-body">
                    <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
                        <div class="float-left">
                            <i class="fa-solid fa-money-check-dollar fa-2xl" style="color: #28a745;"></i>
                        </div>
                        <div class="float-right">
                            <p class="mb-0 text-right">Active Subscriptions</p>
                            <div class="fluid-container">
                                <h3 class="font-weight-medium text-right mb-0"><?php echo e($activeSubscriptions); ?></h3>
                            </div>
                        </div>
                    </div>
                    <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
                        Total Invested: ₨<?php echo e(number_format($totalInvestedAmount)); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings and Financial Summary -->
    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Financial Summary</h4>
                    <div class="row">
                        <div class="col-6">
                            <div class="text-center">
                                <h5 style="color: #007bff;">₨<?php echo e(number_format($totalInvestedAmount)); ?></h5>
                                <p class="text-muted">Total Invested</p>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="text-center">
                                <h5 style="color: #28a745;">₨<?php echo e(number_format($totalEarnings)); ?></h5>
                                <p class="text-muted">Total Earnings</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Plan Distribution</h4>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Plan</th>
                                    <th>Active Users</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $planBreakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($plan['plan_name']); ?></td>
                                    <td><span class="badge" style="background-color: #28a745;"><?php echo e($plan['active_count']); ?></span></td>
                                    <td>₨<?php echo e(number_format($plan['amount'])); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities -->
    <div class="row">
        <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Recent Users</h4>
                    <div class="list-wrapper">
                        <?php $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 class="mb-0"><?php echo e($user->name); ?></h6>
                                <small class="text-muted"><?php echo e($user->email); ?></small>
                            </div>
                            <small class="text-muted"><?php echo e($user->created_at->diffForHumans()); ?></small>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Recent Withdrawals</h4>
                    <div class="list-wrapper">
                        <?php $__currentLoopData = $recentWithdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 class="mb-0"><?php echo e($withdrawal->user->name ?? 'N/A'); ?></h6>
                                <small class="text-muted">₨<?php echo e(number_format($withdrawal->amount)); ?></small>
                            </div>
                            <span class="badge badge-<?php echo e($withdrawal->status == 'requested' ? 'warning' : ($withdrawal->status == 'transferred' ? 'success' : 'secondary')); ?>" 
                                  style="background-color: <?php echo e($withdrawal->status == 'requested' ? '#ffc107' : ($withdrawal->status == 'transferred' ? '#28a745' : '#6c757d')); ?>;">
                                <?php echo e(ucfirst($withdrawal->status)); ?>

                            </span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Recent Deposits</h4>
                    <div class="list-wrapper">
                        <?php $__currentLoopData = $recentDeposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h6 class="mb-0"><?php echo e($deposit->user->name ?? 'N/A'); ?></h6>
                                <small class="text-muted">₨<?php echo e(number_format($deposit->amount)); ?></small>
                            </div>
                            <span class="badge badge-<?php echo e($deposit->status == 'deposited' ? 'warning' : ($deposit->status == 'completed' ? 'success' : 'secondary')); ?>"
                                  style="background-color: <?php echo e($deposit->status == 'deposited' ? '#ffc107' : ($deposit->status == 'completed' ? '#28a745' : '#6c757d')); ?>;">
                                <?php echo e(ucfirst($deposit->status)); ?>

                            </span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <?php echo Html::script('/assets/plugins/chartjs/chart.min.js'); ?>

    <?php echo Html::script('/assets/plugins/jquery-sparkline/jquery.sparkline.min.js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <?php echo Html::script('/assets/js/dashboard.js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/admin/dashboard.blade.php ENDPATH**/ ?>