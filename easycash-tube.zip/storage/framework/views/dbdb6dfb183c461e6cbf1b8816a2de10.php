

<?php $__env->startPush('plugin-styles'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Wallet & Earnings</h2>
    
    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card card-body text-center">
                <h5>Wallet Balance</h5>
                <h3><?php echo e($walletBalance); ?> PKR</h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card card-body text-center">
                <h5>Total Earned</h5>
                <h3><?php echo e($totalEarnings); ?> PKR</h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card card-body text-center">
                <h5>Total Withdrawn</h5>
                <h3><?php echo e($totalWithdrawals); ?> PKR</h3>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card card-body text-center">
                <h5>Bonus Earnings</h5>
                <h3><?php echo e($bonusEarnings); ?> PKR</h3>
            </div>
        </div>
    </div>

    <!-- Daily Earnings Chart -->
    <div class="card mb-4">
        <div class="card-header">
            <h5>Daily Earnings (Last 30 Days)</h5>
        </div>
        <div class="card-body">
            <canvas id="earningsChart" width="400" height="200"></canvas>
        </div>
    </div>

    <!-- Transaction History -->
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Recent Withdrawals</h5>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $withdrawals->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <strong><?php echo e($withdrawal->amount); ?> PKR</strong>
                                <br>
                                <small class="text-muted"><?php echo e($withdrawal->created_at->format('M d, Y')); ?></small>
                            </div>
                            <span class="badge bg-<?php echo e($withdrawal->status == 'transferred' ? 'success' : ($withdrawal->status == 'requested' ? 'warning' : 'secondary')); ?>">
                                <?php echo e(ucfirst($withdrawal->status)); ?>

                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted">No withdrawals yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Recent Deposits</h5>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $deposits->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <strong><?php echo e($deposit->amount); ?> PKR</strong>
                                <br>
                                <small class="text-muted"><?php echo e($deposit->created_at->format('M d, Y')); ?></small>
                            </div>
                            <span class="badge bg-<?php echo e($deposit->status == 'approved' ? 'success' : ($deposit->status == 'deposited' ? 'warning' : 'secondary')); ?>">
                                <?php echo e(ucfirst($deposit->status)); ?>

                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted">No deposits yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings Breakdown -->
    <div class="card mt-4">
        <div class="card-header">
            <h5>Earnings Breakdown</h5>
        </div>
        <div class="card-body">
            <?php $__empty_1 = true; $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <strong><?php echo e($subscription->plan ? $subscription->plan->title : 'Unknown Plan'); ?></strong>
                    </div>
                    <div class="col-md-3">
                        <span class="text-muted">Daily Profit:</span> <?php echo e($subscription->plan ? $subscription->plan->daily_profit : 0); ?> PKR
                    </div>
                    <div class="col-md-3">
                        <span class="text-muted">Total Earned:</span> <?php echo e($subscription->earning); ?> PKR
                    </div>
                    <div class="col-md-2">
                        <span class="badge bg-<?php echo e($subscription->expire_at > date('Y-m-d') ? 'success' : 'secondary'); ?>">
                            <?php echo e($subscription->expire_at > date('Y-m-d') ? 'Active' : 'Expired'); ?>

                        </span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted">No subscriptions found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->startPush('plugin-scripts'); ?>
    <?php echo Html::script('/assets/plugins/chartjs/chart.min.js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Prepare data for chart
    const dates = <?php echo json_encode(array_keys($dailyEarnings), 15, 512) ?>;
    const earnings = <?php echo json_encode(array_values($dailyEarnings), 15, 512) ?>;
    
    const ctx = document.getElementById('earningsChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Daily Earnings (PKR)',
                data: earnings,
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/user/wallet/index.blade.php ENDPATH**/ ?>