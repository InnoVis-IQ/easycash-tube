<?php $__env->startPush('plugin-styles'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-2">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-success">
            <i class="fa-solid fa-check-circle me-2"></i>
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-exclamation-triangle me-2"></i>
            <?php echo e(Session::get('error')); ?>

        </div>
    <?php endif; ?>

    <!-- Wallet Balance -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card card-body text-center">
                <h5><i class="fa-solid fa-wallet me-2"></i>Wallet Balance</h5>
                <h3><?php echo e($walletBalance); ?> PKR</h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-body text-center">
                <h5><i class="fa-solid fa-play-circle me-2"></i>Active Plans</h5>
                <h3><?php echo e($userSubscriptions->count()); ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-body text-center">
                <h5><i class="fa-solid fa-compass-drafting me-2"></i>Available Plans</h5>
                <h3><?php echo e($allPlans->count()); ?></h3>
            </div>
        </div>
    </div>

    <!-- Available Plans -->
    <div class="card mb-4">
        <div class="card-header">
            <h4 style="font-weight: bold;"><i class="fa-solid fa-compass-drafting me-2"></i>Available Investment Plans</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $allPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100 <?php echo e($plan->is_purchased ? 'border-success' : ''); ?>">
                            <div class="card-header text-center bg-success text-white">
                                <?php if($plan->description): ?>
                                <span class="badge bg-danger me-1 text-white text-start" style="font-size: 0.8em;">
                                    <i class="fa-solid fa-fire text-white me-1"></i> <?php echo e($plan->description); ?>

                                </span>
                                <?php endif; ?>
                                <h5 class="mb-0"><?php echo e($plan->title); ?></h5>
                                <?php if($plan->is_purchased): ?>
                                    <span class="badge bg-warning text-black">Already Purchased</span>
                                <?php elseif($plan->can_upgrade): ?>
                                    <span class="badge bg-warning text-black">Available</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary text-black">Insufficient Balance</span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <div class="row mb-2">
                                    <div class="col-6">Price:</div>
                                    <div class="col-6 text-end"><?php echo e($plan->amount); ?> PKR</div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6">Daily Return:</div>
                                    <div class="col-6 text-end"><?php echo e($plan->daily_profit); ?> PKR</div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6">Total Return:</div>
                                    <div class="col-6 text-end"><?php echo e($plan->total_profit); ?> PKR</div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6">Duration:</div>
                                    <div class="col-6 text-end"><?php echo e($plan->plan_days); ?> days</div>
                                </div>
                                <?php if($plan->description): ?>
                                    <div class="row mb-3">
                                        <div class="col-12">
                                            <small class="text-muted"><?php echo e($plan->description); ?></small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="text-center">
                                    <?php if($plan->is_purchased): ?>
                                        <button class="btn btn-success" disabled>
                                            <i class="fas fa-check"></i> Purchased
                                        </button>
                                    <?php elseif($plan->can_upgrade): ?>
                                        <form action="<?php echo e(route('userSubscriptions.store')); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="user" value="<?php echo e(Auth::user()['id']); ?>">
                                            <button class="btn btn-primary" name="invest" value="<?php echo e($plan->id); ?>">
                                                <i class="fas fa-plus"></i> Subscribe Now
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <button class="btn btn-secondary" disabled>
                                            <i class="fas fa-lock"></i> Insufficient Balance
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <!-- My Active Subscriptions -->
    <?php if($userSubscriptions->count() > 0): ?>
        <div class="card">
            <div class="card-header">
                <h4 style="font-weight: bold;"><i class="fa-solid fa-play-circle me-2"></i>My Active Subscriptions</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Plan</th>
                                <th>Amount</th>
                                <th>Profit Earned</th>
                                <th>Duration</th>
                                <th>Subscription Date</th>
                                <th>Expiry Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $userSubscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($subscription->plan->title); ?></td>
                                    <td><?php echo e($subscription->plan->amount); ?> PKR</td>
                                    <td><?php echo e($subscription->earning); ?> PKR</td>
                                    <td><?php echo e($subscription->plan->plan_days); ?> days</td>
                                    <td><?php echo e($subscription->created_at->format('M d, Y')); ?></td>
                                    <td><?php echo e($subscription->expire_at->format('M d, Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('videos.watch')); ?>" class="btn btn-sm btn-primary">
                                            <i class="fa-solid fa-play"></i> Watch Videos
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>



<style>
/* Mobile specific styles */
@media (max-width: 768px) {
    .container-fluid {
        padding-left: 10px;
        padding-right: 10px;
    }
    
    .card-body {
        padding: 0.75rem;
    }
    
    .btn-sm {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
    }
    
    .table-responsive {
        font-size: 0.875rem;
    }
    

    
    .card-header {
        padding: 0.75rem;
    }
}

@media (max-width: 576px) {
    .col-12 {
        margin-bottom: 0.5rem;
    }
    
    .table-responsive {
        font-size: 0.75rem;
    }
    
    .btn-sm {
        font-size: 0.75rem;
        padding: 0.2rem 0.4rem;
    }
}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/user/investmentPlans/index.blade.php ENDPATH**/ ?>