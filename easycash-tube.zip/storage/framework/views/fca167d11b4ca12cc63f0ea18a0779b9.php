<?php $__env->startPush('plugin-styles'); ?>
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/rowreorder/1.3.3/css/rowReorder.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $route = explode('.', Route::currentRouteName());
    ?>
    <div class="nav-container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="<?php echo e(route($route[0] . '.index')); ?>"><?php echo e(ucfirst($route[0])); ?></a></li>
            <a href="<?php echo e(route('users.export')); ?>" class="btn btn-sm btn-success breadcrumb-button" style="background-color: #28a745; border-color: #28a745;">
                <i class="fa-solid fa-download"></i> Export CSV
            </a>
        </ol>
    </div>

    <!-- Search and Filter Section -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('users.index')); ?>" class="row">
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="Search by name, email, phone..." 
                           value="<?php echo e($search ?? ''); ?>">
                </div>
                <div class="col-md-2">
                    <select name="role" class="form-control">
                        <option value="">All Roles</option>
                        <option value="user" <?php echo e(($role ?? '') == 'user' ? 'selected' : ''); ?>>User</option>
                        <option value="admin" <?php echo e(($role ?? '') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                        <option value="superadmin" <?php echo e(($role ?? '') == 'superadmin' ? 'selected' : ''); ?>>Super Admin</option>
                        <option value="restricted" <?php echo e(($role ?? '') == 'restricted' ? 'selected' : ''); ?>>Restricted</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-control">
                        <option value="">All Status</option>
                        <option value="active" <?php echo e(($status ?? '') == 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e(($status ?? '') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary" style="background-color: #007bff; border-color: #007bff;">Filter</button>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Clear</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 style="font-weight: bold;">Users Management</h4>
            <p class="text-muted mb-0">Total Users: <?php echo e($data->total()); ?> | Showing <?php echo e($data->count()); ?> results</p>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table" id='responsive-datatables'>
                    <thead>
                        <tr>
                            <th>Sr</th>
                            <th>User Info</th>
                            <th>Contact</th>
                            <th>Status</th>
                            <th>Wallet Balance</th>
                            <th>Active Plans</th>
                            <th>Signup Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $ser = 0;
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()['role'] != 'SUPERADMIN' && in_array($item['role'], ['SUPERADMIN', 'ADMIN'])): ?>
                                <?php continue; ?>
                            <?php endif; ?>
                            <?php
                                $bg = $item->trashed() ? 'bg-secondary' : '';
                                $activePlans = $item->subscriptions->where('expire_at', '>', date('Y-m-d'))->count();
                                $totalEarnings = $item->subscriptions->sum('earning');
                            ?>
                            <tr>
                                <td class="<?php echo e($bg); ?>"><?php echo e(++$ser); ?></td>
                                <td class="<?php echo e($bg); ?>">
                                    <div>
                                        <strong><?php echo e($item['name']); ?></strong><br>
                                        <small class="text-muted"><?php echo e($item['email']); ?></small><br>
                                        <small class="text-info">Referred by: <?php echo e($item['referred_by'] ? $referrals[$item['referred_by']] : 'Direct'); ?></small>
                                    </div>
                                </td>
                                <td class="<?php echo e($bg); ?>">
                                    <?php echo e($item['contact'] ?? 'N/A'); ?>

                                </td>
                                <td class="<?php echo e($bg); ?>">
                                    <?php if($item->trashed()): ?>
                                        <span class="badge badge-danger" style="background-color: #dc3545;">Inactive</span>
                                    <?php else: ?>
                                        <span class="badge badge-<?php echo e($item['role'] == 'user' ? 'success' : ($item['role'] == 'admin' ? 'warning' : 'info')); ?>"
                                              style="background-color: <?php echo e($item['role'] == 'user' ? '#28a745' : ($item['role'] == 'admin' ? '#ffc107' : '#007bff')); ?>;">
                                            <?php echo e(ucfirst($item['role'])); ?>

                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="<?php echo e($bg); ?>">
                                    <div>
                                        <strong>₨<?php echo e(number_format($item['userAccount']['net_amount'] ?? 0)); ?></strong><br>
                                        <small class="text-muted">Earnings: ₨<?php echo e(number_format($totalEarnings)); ?></small>
                                    </div>
                                </td>
                                <td class="<?php echo e($bg); ?>">
                                    <span class="badge badge-primary" style="background-color: #007bff;"><?php echo e($activePlans); ?></span>
                                </td>
                                <td class="<?php echo e($bg); ?>">
                                    <?php echo e($item['created_at']->format('M d, Y')); ?><br>
                                    <small class="text-muted"><?php echo e($item['created_at']->diffForHumans()); ?></small>
                                </td>
                                <td class="<?php echo e($bg); ?>">
                                    <?php if($item['role'] == 'RESTRICTED'): ?>
                                        <form method="POST" action="<?php echo e(route($route[0] . '.update', $item['id'])); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" name="role" value="approve" class="btn btn-success btn-sm" style="background-color: #28a745; border-color: #28a745;">
                                                <i class='fa-regular fa-circle-check'></i> Approve
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('users.show', $item['id'])); ?>" class="btn btn-info btn-sm" style="background-color: #007bff; border-color: #007bff;">
                                                <i class="fa-solid fa-eye"></i>
                                            </a>
                                            <?php if($item->trashed()): ?>
                                                <form method="POST" action="<?php echo e(route($route[0] . '.update', $item['id'])); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" name="status" value="activate" class="btn btn-success btn-sm" style="background-color: #28a745; border-color: #28a745;">
                                                        <i class="fa-solid fa-check"></i>
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <form method="POST" action="<?php echo e(route($route[0] . '.update', $item['id'])); ?>" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" name="status" value="deactivate" class="btn btn-warning btn-sm" style="background-color: #ffc107; border-color: #ffc107;">
                                                        <i class="fa-solid fa-ban"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            <?php if(Auth::user()['role'] == 'SUPERADMIN'): ?>
                                                <a href="<?php echo e(route('adjustUserAccount',$item['id'])); ?>" class="btn btn-danger btn-sm">
                                                    <i class="fas fa-exclamation-triangle"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($data->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script type="text/javascript" src="https://cdn.datatables.net/rowreorder/1.3.3/js/dataTables.rowReorder.min.js">
    </script>
    <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js">
    </script>
    <?php echo Html::script('/assets/js/dashboard.js'); ?>


    <script>
        $(document).ready(function() {
            var table = $('#responsive-datatables').DataTable({
                rowReorder: {
                    selector: 'td:nth-child(2)'
                },
                responsive: true,
                pageLength: 25,
                order: [[6, 'desc']] // Sort by signup date
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\easycash-tube\resources\views/backend/admin/users/index.blade.php ENDPATH**/ ?>