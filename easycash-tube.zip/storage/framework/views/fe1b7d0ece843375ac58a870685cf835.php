<nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row" style="background: linear-gradient(135deg, #28a745 0%, #007bff 100%);">
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-between w-100">
        <!-- Left section -->
        <div class="d-flex align-items-center">
        </div>
        
        <!-- Center section -->
        <div class="d-flex align-items-center">
            <span class="text-white" style="color: white !important; font-size: 1.1rem; font-weight: 600;">EasyPay Tube</span>
        </div>
        
        <!-- Right section -->
        <div class="d-flex align-items-center">
            <ul class="navbar-nav navbar-nav-right">
                <li class="nav-item dropdown d-none d-xl-inline-block">
                    <a class="nav-link dropdown-toggle text-white" id="UserDropdown" href="#" data-toggle="dropdown"
                        aria-expanded="false" style="color: white !important;">
                        <span class="profile-text d-none d-md-inline-flex text-white" style="color: white !important;"><?php echo e(Auth::user()['name']); ?></span>
                        <img class="img-xs rounded-circle" src="<?php echo e(url('assets/images/faces/face0.png')); ?>" alt="Profile image">
                    </a>
                    <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('password.change')); ?>">
                            <i class="dropdown-item-icon mdi mdi-account-key text-primary"></i>
                            Change Password
                        </a>
                        <?php if(Auth::user()->role == 'USER'): ?>
                        <a class="dropdown-item" href="<?php echo e(route('support.index')); ?>">
                            <i class="dropdown-item-icon mdi mdi-help-circle text-primary"></i>
                            Support & Help
                        </a>
                        <?php else: ?>
                        <a class="dropdown-item" href="<?php echo e(route('admin.settings')); ?>">
                            <i class="dropdown-item-icon mdi mdi-settings text-primary"></i>
                            Settings
                        </a>
                        <?php endif; ?>
                        <div class="dropdown-divider"></div>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item">
                                <i class="dropdown-item-icon mdi mdi-logout text-primary"></i>
                                Logout
                            </button>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\laragon\www\easycash-tube\resources\views/layout/header.blade.php ENDPATH**/ ?>